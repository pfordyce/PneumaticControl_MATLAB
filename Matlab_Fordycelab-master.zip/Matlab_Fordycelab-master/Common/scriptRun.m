function scriptRun(scrFname, scr, chip, camera, scope, mfcs, galil)

    clear(scrFname);
    eval(scrFname);

end